#include "othergoodspage.h"
#include "ui_othergoodspage.h"
extern QString UserAccount;
OtherGoodsPage::OtherGoodsPage(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::OtherGoodsPage)
{
    ui->setupUi(this);
    ui->BackBt->setFixedSize(width_Change(0.1),width_Change(0.1));
    this->setLayout(ui->verticalLayout);
    ui->AttentionGoodsPage->setLayout(ui->AttentionGoodsPage_verticalLayout);



    baseWidget=new QWidget;
    baseGridLayout=new QGridLayout;
    baseWidget->setLayout(baseGridLayout);
    ui->scrollArea->setWidget(baseWidget);
    baseWidget->setFixedWidth(width_Change(0.9930));

    AttionList_TcpSocket=new QTcpSocket(this);
    connect(AttionList_TcpSocket, SIGNAL(connected()), this, SLOT(sendMessage()));
    connect(AttionList_TcpSocket, SIGNAL(readyRead()), this, SLOT(receiveMessage()));

    ReceiveProcuctMessageTcp=new ReceiveProductTcpMessage(AttionList_TcpSocket);
    connect(ReceiveProcuctMessageTcp,SIGNAL(SendTheList(QList<Procuct>)),this,SLOT(SetProductWidget(QList<Procuct>)));
}
void OtherGoodsPage::SetProductWidget(QList<Procuct> thelist)
{
    attentionGoodsList=thelist;
    for(int i=1;i<=attentionGoodsList.size();i++)
    {
        if(i%2==1)
            baseGridLayout->addWidget(theItem("￥"+QString::number(attentionGoodsList[i-1].Cost)+"/"+attentionGoodsList[i-1].MassUnit),i/2,0,1,1);
        else
            baseGridLayout->addWidget(theItem("￥"+QString::number(attentionGoodsList[i-1].Cost)+"/"+attentionGoodsList[i-1].MassUnit),i/2-1,1,1,1);
        baseWidget->setFixedHeight(heigth_Change(0.4)*((i-1)/2+1));


        /****************************************88接收推荐列表照片*********************************/
        QFile pictureFile;
        pictureFile.setFileName("FarmProducts/"+attentionGoodsList[i-1].CommodityCode+".jpg");
        if(!pictureFile.exists() || attentionGoodsList[i-1].PictureSize!=QString::number(pictureFile.size()))
        {
            QThread *thread=new QThread;                //申请新线程
            PictureThread *picturehread=new PictureThread(18,"FarmProducts",attentionGoodsList[i-1].CommodityCode);     //创建线程对象
            picturehread->moveToThread(thread);             //把对象移到线程
            connect(picturehread,SIGNAL(SendFileName(QString)),this,SLOT(SetRecommendPicture(QString))); //绑定显示图片事件
            thread->start();
        }//线程运行
        else
        {
             attionwidgetlist[i-1]->AttionGoodsPhone->setStyleSheet(tr("border-image: url(./FarmProducts/%0)").arg(attentionGoodsList[i-1].CommodityCode));
        }
    }
    for(int i=0;i<attionwidgetlist.size();i++)
        attionwidgetlist[i]->AttionGoodsName->setText(setLabelText(attentionGoodsList[i].Synopsis,attionwidgetlist[i]->AttionGoodsName->width()));

}
void OtherGoodsPage::SetRecommendPicture(QString picturename)
{
    for(int i=0;i<attentionGoodsList.size();i++)
    {
        if(picturename==attentionGoodsList[i].CommodityCode)
        {
            attionwidgetlist[i]->AttionGoodsPhone->setStyleSheet(tr("border-image: url(./FarmProducts/%0)").arg(attentionGoodsList[i].CommodityCode));
        }
    }
}

void OtherGoodsPage::showEvent(QShowEvent *event)
{

    newConnect(AttionList_TcpSocket);

}

void OtherGoodsPage::sendMessage()
{
    if(sender()==AttionList_TcpSocket)
    {
        SendTcpMessage("26",AttionList_TcpSocket);
        SendTcpMessage(UserAccount,AttionList_TcpSocket);
    }
}

void OtherGoodsPage::receiveMessage()
{
    if(sender()==AttionList_TcpSocket)
    {
        ReceiveProcuctMessageTcp->Receivelist();
    }
}

QWidget *OtherGoodsPage::theItem(QString money)
{
    QWidget *base=new QWidget;
    QLabel *AttionGoodsPhone=new QLabel;
    QLabel *AttionGoodsName=new QLabel;
    QLabel *AttionGoodsMoney=new QLabel(money);
    QPushButton *AttionGoodsLike=new QPushButton("找相似");
    QSpacerItem *HSpacerItem=new QSpacerItem(1,1,QSizePolicy::Expanding, QSizePolicy::Minimum);

    base->setFixedHeight(heigth_Change(0.4));
    AttionGoodsPhone->setFixedHeight(heigth_Change(0.32));
    AttionGoodsName->setFixedHeight(heigth_Change(0.025));
    AttionGoodsMoney->setFixedHeight(heigth_Change(0.025));
    AttionGoodsLike->setFixedHeight(heigth_Change(0.025));


    base->setStyleSheet("background-color:#ffffff");
    AttionGoodsName->setStyleSheet("color:black;");
    AttionGoodsMoney->setStyleSheet("color: rgb(255, 128, 44);");
    AttionGoodsLike->setStyleSheet("border:none;border-radius:8px;color: rgb(255, 128, 44); border:1px solid rgb(255, 209, 93);");

    QHBoxLayout *Money_LooksLike_HBoxLayout=new QHBoxLayout;
    Money_LooksLike_HBoxLayout->addWidget(AttionGoodsMoney);
    Money_LooksLike_HBoxLayout->addItem(HSpacerItem);
    Money_LooksLike_HBoxLayout->addWidget(AttionGoodsLike);

    QVBoxLayout *itemVBoxLayout=new QVBoxLayout ;
    itemVBoxLayout->addWidget(AttionGoodsPhone);
    itemVBoxLayout->addWidget(AttionGoodsName);
    itemVBoxLayout->addLayout(Money_LooksLike_HBoxLayout);

    AttionGoodsName->setAlignment(Qt::AlignCenter);
    base->setLayout(itemVBoxLayout);

    AttionWidget *item=new AttionWidget(base,AttionGoodsPhone,AttionGoodsName,AttionGoodsMoney,AttionGoodsLike,HSpacerItem,Money_LooksLike_HBoxLayout,itemVBoxLayout);
    attionwidgetlist.push_back(item);
    return base;
}

OtherGoodsPage::~OtherGoodsPage()
{
    for(int i=0;i<attionwidgetlist.size();i++)
    {
        delete attionwidgetlist[i];
    }
    delete baseGridLayout;
    delete baseWidget;
    delete ui;
    qDebug()<<"日你婆";
}
void OtherGoodsPage::closeEvent(QCloseEvent *event)
{
    emit theAttentionClose();
}

void OtherGoodsPage::on_BackBt_clicked()
{
    this->close();
}
