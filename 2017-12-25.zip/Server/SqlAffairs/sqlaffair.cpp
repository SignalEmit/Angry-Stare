#include "sqlaffair.h"
#include<QString>
template<class T>
SqlAffair<T>::SqlAffair(QTcpSocket *receiveSocket_):receiveSocket(receiveSocket_)
{
    if(QSqlDatabase::contains("qt_sql_default_connection"))
      db = QSqlDatabase::database("qt_sql_default_connection");
    else
      db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("Database/Message.db");
}
template<class T>
bool SqlAffair<T>::is_theItemExits(QString sql)
{
    QSqlQuery theitemexist;
    theitemexist.exec(sql);
    if(theitemexist.next())
        return true;
    else
        return false;
}
template<class T>
bool SqlAffair<T>::is_perforMaction(QString sql)
{
    QSqlQuery theExec;
    return theExec.exec(sql);
}
template<class T>
int SqlAffair<T>::checkItemCount(QString sql)
{
    QSqlQuery checkSql;
    if(checkSql.exec(sql))
    {
        checkSql.next();                                //游标下移
        return checkSql.value(0).toInt();
    }
}
/**********************好麻烦  不搞了*********************/
template<class T>
void SqlAffair<T>::sqlgogo(QString sql_count,QString sql_sendlist)
{
    SendTcpMessage(sql_count,receiveSocket);
    QSqlQuery findmessage;
    findmessage.exec(sql_sendlist);
    while(findmessage.next())
    {
        if(typeid(T)==typeid(QString))
        {
            SendTcpMessage(findmessage.value(0).toString(),receiveSocket);
        }

    }
}
