#ifndef SQLAFFAIR_H
#define SQLAFFAIR_H

#include<QtSql>
#include<QSqlDatabase>
#include<QSqlQuery>
#include<QTcpSocket>
#include<QDebug>
#include<DataTransfer/datatransfer.h>
template<class T>
class SqlAffair:public DataTransfer
{
private:
    QTcpSocket *receiveSocket;
    QSqlDatabase db;
    T a;
public:
    SqlAffair(){}
    SqlAffair(QTcpSocket *receiveSocket_);
    bool is_theItemExits(QString sql);
    bool is_perforMaction(QString sql);
    int checkItemCount(QString sql);                            //查询共有多少条SQl
    void sqlgogo(QString sql_count,QString sql_sendlist);
};

#endif // SQLAFFAIR_H
