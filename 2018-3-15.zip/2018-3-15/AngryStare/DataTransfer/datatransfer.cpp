#include"datatransfer.h"
DataTransfer::DataTransfer()
{
    blockSize=0;
}
/*****************************8序列化PayMessage ******************************/
QDataStream& operator<<(QDataStream &out, PayMessage &data)
{
    out<<data.OrderCommodityCode<<data.PayGoodsMassUnit<<data.PayGoodsNumber<<data.PayGoodsMoney<<data.CommodityCode<<data.ProductName<<data.Cost<<data.Number<<data.Synopsis<<data.MassUnit<<data.PictureLocation<<data.Postage<<data.Promulgator<<data.ContactNumber;
    return out;
}
void DataTransfer::SendTcpPaySuccessGoods(PayMessage &message,QTcpSocket *tcpSocket)
{
    QByteArray data;			//暂时要发送的数据
    QDataStream out(&data, QIODevice::WriteOnly);
    out.setVersion(QDataStream::Qt_5_8);						//设置数据流版本
    out << (quint16)0;
    out << message;
    out.device()->seek(0);
    out << (quint16)(data.size() - sizeof(quint16));
    tcpSocket->write(data);
}
/********************************************88接收农产品************************************************/
/********************************************88接收农产品************************************************/
/********************************************88接收农产品************************************************/

#ifndef QT_NO_DATASTREAM
QDataStream& operator>>(QDataStream &in, Procuct &data)
{
    in>>data.ProductName>>data.CommodityCode>>data.Cost>>data.Number>>data.Synopsis>>data.MassUnit>>data.PictureLocation>>data.Postage>>data.Promulgator>>data.ContactNumber;
    return in;
}
#endif

void DataTransfer::receiveTcpMessage_FarmPruduct(Procuct &_list,QTcpSocket *tcpSocket)
{
    Procuct message;
    QDataStream in(tcpSocket);
    in.setVersion(QDataStream::Qt_5_8);
    if (blockSize == 0)
    {
        if (tcpSocket->bytesAvailable() <(int)sizeof(quint16)) return;
        in >> blockSize;
    }
    if (tcpSocket->bytesAvailable() < blockSize) return;
    in >> message;
    blockSize = 0;
    _list=message;
}
/******************************8接收消息*******************************/
void DataTransfer::receiveTcpMessage(QString &Judge,QTcpSocket *tcpSocket)
{
    QByteArray message;
    QDataStream in(tcpSocket);
    in.setVersion(QDataStream::Qt_5_8);
    if (blockSize == 0)
    {
        if (tcpSocket->bytesAvailable() <(int)sizeof(quint16)) return;
        in >> blockSize;
    }
    if (tcpSocket->bytesAvailable() < blockSize) return;
    in >> message;
    blockSize = 0;
    Judge=message;
    qDebug()<<Judge;

}
/******************************发送消息*******************************/
void DataTransfer::SendTcpMessage(QString message,QTcpSocket *tcpSocket_1)
{
    qDebug()<<"发送数字："<<message;
    QByteArray ByteArray; //用于暂存我们要发送的数据
    QDataStream out(&ByteArray, QIODevice::WriteOnly);
    out<< (quint16)0;
    out<< message.toUtf8();
    qDebug() << message;
    out.device()->seek(0);
    out<< (quint16)(ByteArray.size() - sizeof(quint16));
    tcpSocket_1->write(ByteArray);
}
QDataStream& operator<<(QDataStream &out, Procuct &data)
{
    out<<data.ProductName<<data.CommodityCode<<data.Cost<<data.Number<<data.Synopsis<<data.MassUnit<<data.PictureLocation<<data.Postage<<data.Promulgator<<data.ContactNumber;
    return out;
}

/******************************发送对象*******************************/
void DataTransfer::SendTcpMessage_List(QTcpSocket *tcpSocket_1,Procuct message)
{
    qDebug()<<"发送编号"<<message.CommodityCode;
    QByteArray data;			//暂时要发送的数据
    QDataStream out(&data, QIODevice::WriteOnly);
    out.setVersion(QDataStream::Qt_5_8);						//设置数据流版本
    out << (quint16)0;
    out << message;
    out.device()->seek(0);
    out << (quint16)(data.size() - sizeof(quint16));
    tcpSocket_1->write(data);
}

QDataStream& operator<<(QDataStream &out, Friend &data)
{
    out<<data.FriendCount<<data.Remark<<data.Age<<data.NickName<<data.Sex<<data.Area<<data.NoYesFriend<<data.FriendPictureSize;
    return out;
}
/******************************发送朋友列表*******************************/
void DataTransfer::SendTcpMessage_Friend(Friend myfriend,QTcpSocket *tcpSocket_1)
{
    QByteArray data;			//暂时要发送的数据
    QDataStream out(&data, QIODevice::WriteOnly);
    out.setVersion(QDataStream::Qt_5_8);						//设置数据流版本
    out << (quint16)0;
    out << myfriend;
    out.device()->seek(0);
    out << (quint16)(data.size() - sizeof(quint16));
    tcpSocket_1->write(data);

}
QDataStream& operator>>(QDataStream &in, Friend &data)
{
    in>>data.FriendCount>>data.Remark>>data.Age>>data.NickName>>data.Sex>>data.Area>>data.NoYesFriend>>data.FriendPictureSize;
    return in;
}
void DataTransfer::ReceiveMyMessage(Friend &myMessage,QTcpSocket *tcpSocket)
{
    QDataStream in(tcpSocket);
    in.setVersion(QDataStream::Qt_5_8);
    if (blockSize == 0)
    {
        if (tcpSocket->bytesAvailable() <(int)sizeof(quint16)) return;
        in >> blockSize;
    }
    if (tcpSocket->bytesAvailable() < blockSize) return;
    in >> myMessage;
    blockSize=0;
}

