#ifndef OTHERGOODSPAGE_H
#define OTHERGOODSPAGE_H

#include <QWidget>
#include<QGridLayout>
#include<QHBoxLayout>
#include<QVBoxLayout>
#include<QLabel>
#include<QPushButton>
#include<QSpacerItem>
#include<QList>
#include<QTcpSocket>
#include"tcpclass.h"
#include<QDebug>
#include"receivetcpmessage.h"
#include"picturethread.h"
class AttionWidget
{
public:
    QWidget *base;
    QLabel *AttionGoodsPhone;
    QLabel *AttionGoodsName;
    QLabel *AttionGoodsMoney;
    QPushButton *AttionGoodsLike;
    QSpacerItem *HSpacerItem;

    QHBoxLayout *Money_LooksLike_HBoxLayout;
    QVBoxLayout *itemVBoxLayout;
    AttionWidget(QWidget *base_,QLabel *AttionGoodsPhone_,QLabel *AttionGoodsName_,QLabel *AttionGoodsMoney_,QPushButton *AttionGoodsLike_,
                 QSpacerItem *HSpacerItem_,QHBoxLayout *Money_LooksLike_HBoxLayout_,QVBoxLayout *itemVBoxLayout_):base(base_),AttionGoodsPhone(AttionGoodsPhone_),AttionGoodsName(AttionGoodsName_),
                AttionGoodsMoney(AttionGoodsMoney_),AttionGoodsLike(AttionGoodsLike_),HSpacerItem(HSpacerItem_),Money_LooksLike_HBoxLayout(Money_LooksLike_HBoxLayout_),
                 itemVBoxLayout(itemVBoxLayout_){}
    ~AttionWidget()
    {

        delete AttionGoodsPhone;
        delete AttionGoodsName;
        delete AttionGoodsMoney;
        delete AttionGoodsLike;


        delete Money_LooksLike_HBoxLayout;
        delete itemVBoxLayout;
        delete base;
    }
};

namespace Ui {
class OtherGoodsPage;
}

class OtherGoodsPage : public QWidget,public TcpClass
{
    Q_OBJECT
signals:
    void theAttentionClose();
public:
    explicit OtherGoodsPage(QWidget *parent = 0);
    ~OtherGoodsPage();
private:
    QTcpSocket *AttionList_TcpSocket;
    QList<AttionWidget*> attionwidgetlist;
    QList<Procuct> attentionGoodsList;
    QWidget *baseWidget;
    QGridLayout *baseGridLayout;
    QWidget *theItem(QString money);
    ReceiveProductTcpMessage *ReceiveProcuctMessageTcp;
    Ui::OtherGoodsPage *ui;
private:
    void closeEvent(QCloseEvent *event);
    void showEvent(QShowEvent *event);
private slots:
    void sendMessage();
    void receiveMessage();
    void SetProductWidget(QList<Procuct>);
    void SetRecommendPicture(QString);                  //设置图片
    void on_BackBt_clicked();
};

#endif // OTHERGOODSPAGE_H
