#include "home.h"
#include<QDebug>
QMap<QString,OnlinePeople> OnlinePeopleMap;           //在线用户map
Home::Home()
{
    ThreadCount=0;
    tcpServer = new QTcpServer(this);
    if (!tcpServer->listen(QHostAddress::AnyIPv4, 666))
    {
        qDebug() << tcpServer->errorString();
    }
    connect(tcpServer, SIGNAL(newConnection()), this, SLOT(monitor()));


    /***************数据库****************/
    if(QSqlDatabase::contains("qt_sql_default_connection"))
      db = QSqlDatabase::database("qt_sql_default_connection");
    else
      db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("Database/Message.db");

     backonlinethread=new BackOnlineThread;
     connect(backonlinethread,SIGNAL(backUser(QString)),this,SLOT(backOnline(QString)));
     backonlinethread->start();
}
Home::~Home()
{
    for(int i=0;i<ThreadCount;i++)
        delete mythread[ThreadCount];
    delete tcpServer;
    OnlinePeopleMap.clear();           //在线用户list
    qDebug()<<"删除啪啪啪";
}

void Home::monitor()
{
    mythread[ThreadCount]=new MyThread(tcpServer,ThreadCount);
    qDebug()<<&mythread[ThreadCount];
    connect(mythread[ThreadCount],SIGNAL(finished()),mythread[ThreadCount],SLOT(quit()));
    mythread[ThreadCount]->start();//mythread[ThreadCount]->msleep(40);
    while(!mythread[ThreadCount]->isFinished());
    ThreadCount++;
    qDebug()<<"第几个：："<<ThreadCount;
    if(ThreadCount==10000)
        ThreadCount=0;

}
void Home::backOnline(QString user)
{
    QMap<QString,OnlinePeople>::iterator LookUp=OnlinePeopleMap.find(user);
    if(LookUp!=OnlinePeopleMap.end())
    {
        SendTcpMessage("您已被强制下线",LookUp.value().BackOnline());
        OnlinePeopleMap.erase(LookUp);
    }
    else
        std::cout<<"用户:\""<<user.toStdString()<<"\"不存在"<<std::endl;
}

void Home::SendTcpMessage(QString message,QTcpSocket *tcpSocket_1)
{
    QByteArray ByteArray; //用于暂存我们要发送的数据
    QDataStream out(&ByteArray, QIODevice::WriteOnly);
    out<< (quint16)0;
    out<< message.toUtf8();
    qDebug() << message;
    out.device()->seek(0);
    out<< (quint16)(ByteArray.size() - sizeof(quint16));
    tcpSocket_1->write(ByteArray);
}
