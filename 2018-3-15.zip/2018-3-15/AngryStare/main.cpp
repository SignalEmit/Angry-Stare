#include <QCoreApplication>
#include<iostream>
#include<string>
#include<QDir>
#include<QTcpServer>
#include<QObject>
#include"home.h"
int ThreadCount=0;              //线程条数
int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);
    std::cout<<"--------------------------------------------------------"<<std::endl;
    std::cout<<"--------------------------------------------------------"<<std::endl;
    std::cout<<"--------------------------------------------------------"<<std::endl;
    std::cout<<"------------------欢迎使用我是你爸爸服务器------------------"<<std::endl;
    std::cout<<"--------------------------------------------------------"<<std::endl;
    std::cout<<"--------------------------------------------------------"<<std::endl;
    std::cout<<"--------------------------------------------------------"<<std::endl;
    QDir filepath;//新建文件夹
    filepath.mkdir("FarmProducts");
    filepath.mkdir("HeadPicture");
    Home home;
    return a.exec();
}
