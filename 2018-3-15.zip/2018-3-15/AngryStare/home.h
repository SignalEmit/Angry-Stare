#ifndef HOME_H
#define HOME_H

#include<string>
#include<QDir>
#include<QTcpServer>
#include<QObject>
#include<iostream>
#include<QSqlDatabase>
#include"mythread.h"
#include"backonlinethread.h"
class Home:public QObject
{
    Q_OBJECT
private slots:
    void monitor();
private:
    void SendTcpMessage(QString message,QTcpSocket *tcpSocket_1);
    void pushProduct();
    void findProduct();             //查找商品
private:
    QTcpServer *tcpServer;
    QSqlDatabase db;
    MyThread *mythread[10000];
    BackOnlineThread *backonlinethread;
    int ThreadCount;
private slots:
    void backOnline(QString);
public:
    Home();
    ~Home();
};

#endif // HOME_H
