#include "widget.h"
#include <QApplication>
#include<QFile>
#include<QSqlDatabase>
#include<QSqlQuery>
#include"interface.h"
//QSqlDatabase db;
QString UserAccount;
int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Widget w;
    return a.exec();
}
