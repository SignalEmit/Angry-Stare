#include "backonlinethread.h"
#include<QDebug>
#include<cstdlib>
#include<QString>
extern QMap<QString,OnlinePeople> OnlinePeopleMap;           //在线用户map
BackOnlineThread::BackOnlineThread()
{

}
void BackOnlineThread::run()
{
    while(1)
    {
        std::cout<<std::endl;
        std::cout<<std::endl;
        std::cout<<std::endl;

        std::cout<<"按1查看好友列表！！"<<std::endl;
        std::cout<<"按2查看删除好友！！"<<std::endl;
        std::cout<<"请输入您要做的操作"<<std::endl;
        std::string control;
        std::cin>>control;
        QString str=QString::fromStdString(control);
        bool judge=false;
        str.toInt(&judge);
        if(!judge)
        {
            std::cout<<"输入错误请重新输入!!!!"<<std::endl;
            continue;
        }
        switch (str.toInt()) {
        case 1:checkShowUser();break;
        case 2:
        {
            std::cout<<"请输入需要下线的用户：";
            std::string user;
            std::cin>>user;
            emit backUser(QString::fromStdString(user));
        };break;
        }

        std::cout<<std::endl;
        std::cout<<std::endl;
        std::cout<<std::endl;
    }
}

void BackOnlineThread::checkShowUser()
{
    for(auto i=OnlinePeopleMap.begin();i!=OnlinePeopleMap.end();i++)
        std::cout<<"用户:"<<i.key().toStdString()<<std::endl;
}
