#ifndef BACKONLINETHREAD_H
#define BACKONLINETHREAD_H

#include <QObject>
#include<QThread>
#include<string>
#include<iostream>
#include"DataTransfer/datatransfer.h"
class BackOnlineThread : public QThread,public DataTransfer
{
    Q_OBJECT
signals:
    void backUser(QString);
private:
    void checkShowUser();
public:
    BackOnlineThread();
protected:
    void run();
};

#endif // BACKONLINETHREAD_H
